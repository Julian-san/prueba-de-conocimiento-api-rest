/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.apirestjava;

import com.api.bean.Json;
import com.api.bean.Persona;
import com.google.gson.Gson;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author user
 */
@Path("apiprueba")
public class ApipruebaResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of ApipruebaResource
     */
    public ApipruebaResource() {
    }

    /**
     * Retrieves representation of an instance of
     * com.mycompany.apirestjava.ApipruebaResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String consultapersona(@QueryParam("nombre") String nombre,
            @QueryParam("profesion") String profesion,
            @QueryParam("edad") int edad,
            @QueryParam("lenguajes") String lenguajes,
            @QueryParam("disponibilidadParaViajar") double disponibilidadParaViajar,
            @QueryParam("añosaniosDeExperiencia") int añosaniosDeExperiencia,
            @QueryParam("nivel") String nivel) {
        //TODO return proper representation object
        //throw new UnsupportedOperationException();
        Persona persona = new Persona();
        persona.setNombre(nombre);
        persona.setProfesion(profesion);
        persona.setEdad(edad);
        persona.setLenguajes(lenguajes);
        persona.setDisponibilidadParaViajar(disponibilidadParaViajar);
        persona.setAñosaniosDeExperiencia(añosaniosDeExperiencia);
        persona.setNivel(nivel);

        Json obj = new Json();
        obj.setPersona(persona);
        Gson gson = new Gson();
        String jsonString = gson.toJson(obj);
        return jsonString;
    }

    /**
     * PUT method for updating or creating an instance of ApipruebaResource
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
}
