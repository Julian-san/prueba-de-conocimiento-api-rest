package com.api.bean;

public class Json {
private Persona persona;

public Persona getPersona(){
return persona; 
}

public void setPersona(Persona persona){
this.persona = persona;
}
}
