
package com.api.bean;

public class Persona {

    private String nombre;
    private String profesion;
    private int edad;
    private String lenguajes;
    private double disponibilidadParaViajar;
    private int añosaniosDeExperiencia;
    private String nivel;

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getProfesion() {
        return profesion;
    }
    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }
    public int getEdad() {
        return edad;
    }
    public void setEdad(int edad) {
        this.edad = edad;
    }
    public String getLenguajes() {
        return lenguajes;
    }
    public void setLenguajes(String lenguajes) {
        this.lenguajes = lenguajes;
    }
    public double getDisponibilidadParaViajar() {
        return disponibilidadParaViajar;
    }
    public void setDisponibilidadParaViajar(double disponibilidadParaViajar) {
        this.disponibilidadParaViajar = disponibilidadParaViajar;
    }
    public int getAñosaniosDeExperiencia() {
        return añosaniosDeExperiencia;
    }
    public void setAñosaniosDeExperiencia(int añosaniosDeExperiencia) {
        this.añosaniosDeExperiencia = añosaniosDeExperiencia;
    }
    public String getNivel() {
        return nivel;
    }
    public void setNivel(String nivel) {
        this.nivel = nivel;
    }
}